-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 14. September 2016 jam 19:31
-- Versi Server: 5.1.33
-- Versi PHP: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `persija`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftar_acara`
--

CREATE TABLE IF NOT EXISTS `daftar_acara` (
  `username` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `pertandingan` varchar(100) NOT NULL,
  `home` varchar(50) NOT NULL,
  `away` varchar(50) NOT NULL,
  `jml_tiket` int(10) NOT NULL,
  `harga_tiket` varchar(30) NOT NULL,
  `tribun` varchar(50) NOT NULL,
  `atas_nama` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telepon` varchar(13) NOT NULL,
  `kode_acara` varchar(50) NOT NULL,
  `status1` tinyint(1) NOT NULL,
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `daftar_acara`
--

INSERT INTO `daftar_acara` (`username`, `tanggal`, `pertandingan`, `home`, `away`, `jml_tiket`, `harga_tiket`, `tribun`, `atas_nama`, `email`, `telepon`, `kode_acara`, `status1`) VALUES
('dini', '2016-09-12', 'Persija VS Madura UTD', 'Persija', 'Madura UTD', 1, '200', 'Kategori 2', 'Dini', 'radenkiansantang1928@gmail.com', '089609444118', '73343', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE IF NOT EXISTS `jadwal` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `post_body` varchar(1500) NOT NULL,
  `hari` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `home` varchar(50) NOT NULL,
  `away` varchar(50) NOT NULL,
  `harga_1` varchar(50) NOT NULL,
  `harga_2` varchar(30) NOT NULL,
  `harga_3` varchar(30) NOT NULL,
  `harga_4` varchar(25) NOT NULL,
  `judul_gambar` varchar(30) NOT NULL,
  `nama_file` varchar(50) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`no`, `post_body`, `hari`, `tanggal`, `home`, `away`, `harga_1`, `harga_2`, `harga_3`, `harga_4`, `judul_gambar`, `nama_file`) VALUES
(15, '', 'Senin', '2016-09-19', 'Persija', 'Madura UTD', '100', '200', '300', '400', '', ''),
(14, '<p>Persija Jakarta</p>\r\n', '', '0000-00-00', '', '', '100', '200', '300', '400', 'Persija Jakarta', 'img-upload/Desert.jpg'),
(16, '', 'Selasa', '2016-09-20', 'Persija', 'Gresik United', '100', '200', '300', '400', '', ''),
(17, '', 'Rabu', '2016-09-21', 'Persija', 'Persela', '100', '200', '300', '400', '', ''),
(18, '', 'Kamis', '2016-09-22', 'Persija', 'Persib', '100', '200', '300', '400', '', ''),
(19, '', 'Jumat', '2016-09-23', 'Persija', 'Semen Padang', '100', '200', '300', '400', '', ''),
(20, '', 'Sabtu', '2016-09-24', 'Persija', 'PBFC', '100', '200', '300', '400', '', ''),
(21, '', 'Senin', '2016-09-25', 'Persija', 'Mitra Kukar', '100', '200', '300', '400', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `keuangan`
--

CREATE TABLE IF NOT EXISTS `keuangan` (
  `no` varchar(50) NOT NULL,
  `pertandingan` varchar(50) NOT NULL,
  `home` varchar(50) NOT NULL,
  `away` varchar(50) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `jumlah_tiket` varchar(50) NOT NULL,
  `jumlah_uang` varchar(50) NOT NULL,
  `kode_acara` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `keuangan`
--

INSERT INTO `keuangan` (`no`, `pertandingan`, `home`, `away`, `tanggal`, `user`, `jumlah_tiket`, `jumlah_uang`, `kode_acara`) VALUES
('1', 'Persija VS Madura UTD', 'Persija', 'Madura UTD', '2016-09-11', 'dini', '1', '200', 73343);

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
  `id` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `waktu` varchar(16) NOT NULL,
  `tanggal` date NOT NULL,
  `ket` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `komentar`
--

INSERT INTO `komentar` (`id`, `user`, `waktu`, `tanggal`, `ket`) VALUES
('1', 'dini', '06:19:30 PM', '2016-09-14', '<p>Persija Jakarta</p>\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `konfirmasi`
--

CREATE TABLE IF NOT EXISTS `konfirmasi` (
  `username` varchar(20) NOT NULL,
  `atas_nama` varchar(20) NOT NULL,
  `no_rek` varchar(15) NOT NULL,
  `tgl_transfer` date NOT NULL,
  `jml_transfer` varchar(30) NOT NULL,
  `kode_acara` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `konfirmasi`
--

INSERT INTO `konfirmasi` (`username`, `atas_nama`, `no_rek`, `tgl_transfer`, `jml_transfer`, `kode_acara`, `status`) VALUES
('dini', 'Dini', '123123123', '2016-09-11', '200', '73343', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `post_id` varchar(25) NOT NULL,
  `post_user` varchar(30) NOT NULL,
  `post_judul` varchar(100) NOT NULL,
  `post_body` varchar(1500) NOT NULL,
  `waktu` varchar(16) NOT NULL,
  `tanggal` date NOT NULL,
  `judul_gambar` varchar(30) NOT NULL,
  `nama_file` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `post`
--

INSERT INTO `post` (`post_id`, `post_user`, `post_judul`, `post_body`, `waktu`, `tanggal`, `judul_gambar`, `nama_file`) VALUES
('1', 'dini', 'Persija Jakarta', '<p>Persija Jakarta</p>\r\n', '06:16:12 PM', '2016-09-14', 'Persija Jakarta', 'img-upload/Desert.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tim`
--

CREATE TABLE IF NOT EXISTS `tim` (
  `no` tinyint(3) NOT NULL AUTO_INCREMENT,
  `nama_tim` varchar(50) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data untuk tabel `tim`
--

INSERT INTO `tim` (`no`, `nama_tim`) VALUES
(1, 'Madura UTD'),
(2, 'Gresik United'),
(3, 'Persela'),
(4, 'Persebaya'),
(5, 'Persib'),
(6, 'Arema'),
(7, 'Bali United'),
(8, 'PSM'),
(9, 'Semen Padang'),
(10, 'Sriwijaya'),
(11, 'PS TNI'),
(12, 'Persipura'),
(13, 'Barito Putera'),
(14, 'Mitra Kukar'),
(15, 'PBFC'),
(16, 'Persiba'),
(17, 'Persija');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tribun`
--

CREATE TABLE IF NOT EXISTS `tribun` (
  `no` int(5) NOT NULL,
  `jenis` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tribun`
--

INSERT INTO `tribun` (`no`, `jenis`) VALUES
(1, 'Kateogri 1'),
(2, 'Kateogri 2'),
(3, 'VIP Timur'),
(4, 'VIP Barat ( VVIP )');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `alamat` text NOT NULL,
  `email` varchar(35) NOT NULL,
  `no_telepon` varchar(13) NOT NULL,
  `pertanyaan_keamanan` varchar(60) NOT NULL,
  `jawaban` varchar(60) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`username`, `password`, `nama`, `alamat`, `email`, `no_telepon`, `pertanyaan_keamanan`, `jawaban`, `status`) VALUES
('admin', 'admin', 'Admin', 'Admin', 'Admin', 'Admin', '2', 'sifa', 'admin'),
('ipon', 'ipon', 'Ivon Subekti', 'Tangerang', 'ivonsubekti4@gmail.com', '08976466464', '1', 'Ivon', 'user'),
('sidik', 'sidik', 'Sidik Imam', 'Tangerang', 'imamsidik2@gmail.com', '00909999999', '2', 'Imam', 'user'),
('dini', 'dika', 'dinidika', 'dpk', 'radenkiansantang1928@gmail.com', '1141411', '1', 'rendy', 'user');
